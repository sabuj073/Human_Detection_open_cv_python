# Opencv-face-with-Arduino

In this simple demo I tried to control led hooked to an Arduino-uno microcontroller using the opencv facedetection.

You can find the demo on youtube. video link https://www.youtube.com/watch?v=Zhuh3iWxCHI
